#!/usr/bin/env python3
# _*_ coding: utf-8 _*_

import time


def int_time():
    return int(time.time() * 1000)
