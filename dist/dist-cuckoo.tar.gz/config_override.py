#!/usr/bin/env python3
# _*_ coding: utf-8 _*_

configs = {
    'debug': True,
    'db': {
        'host': '127.0.0.1'
    }
}