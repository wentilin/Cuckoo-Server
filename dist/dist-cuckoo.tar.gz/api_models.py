#!/usr/bin/env python3
# _*_ coding: utf-8_*_


api_models = [
                'api.account',
                'api.user',
                'api.feed',
                'api.friend',
                'api.image',
                'api.comment'
             ]