#!/usr/bin/env python3
# _*_ coding: utf-8 _*_

class Constant(object):
    DEFAULT_IMAGE_WIDTH = 600
    DEFAULT_IMAGE_HEIGHT = 600

    DEFAULT_OFFSET = 0
    DEFAULT_SIZE = 10

    DEFAULT_PAGE = 0
    DEFAULT_PAGE_SIZE = DEFAULT_SIZE