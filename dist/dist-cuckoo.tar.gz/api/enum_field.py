from enum import Enum

class AccountField(Enum):
    name = 1
    phone = 2